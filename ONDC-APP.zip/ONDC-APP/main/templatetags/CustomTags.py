from django import template
import json
register = template.Library()


@register.filter(name='split')
def split(value):
    if value is None:
        return None 
    value = '{'+value+'}'
    return json.loads(value)

'''
@register.filter(name='split')
def split(value, element):
    if value is None:
        return None
    return value.split(element)
    '''