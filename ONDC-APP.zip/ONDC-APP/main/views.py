import os
from config.settings import BASE_DIR
from django.http.response import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import ensure_csrf_cookie
from django.urls import reverse
from django.conf import settings


import pickle
import pandas as pd
 

def predict(id_category,id_weather,id_product,id_seasonality,id_supplyQuantity ,id_demandQuantity,id_location,id_perishableItem,id_quantityInInventory,id_timeFrame):
   
    #model_pkl_file_path ='C:/aiWhiz/ONDC/model_pkl_file.pkl' 
    model_pkl_file_path = os.path.join(BASE_DIR,'pickle',"model_pkl_file.pkl")    
    
    # We expect one argument, the hostname without TLD.
    # Loading the saved KNN model pickle file
    load_model_pkl = open(model_pkl_file_path, 'rb')
    model = pickle.load(load_model_pkl)
   
    input_values = pd.DataFrame({'Seasonality': [], 'Locations': [], 'TimeFrame': [], 'Category': [], 'Demand Quantity': [],
                                 'Item Name': [], 'Quantity in Inventory': [], 'Weather': [], 'Perishable Item': [],
                                 'Supply Quantity': []})
   
    input_values.loc[0,'Seasonality'] = id_seasonality
    input_values.loc[0,'Locations'] = id_location
    input_values.loc[0,'TimeFrame'] = id_timeFrame   
    input_values.loc[0,'Category'] = id_category
    input_values.loc[0,'Demand Quantity'] = id_demandQuantity
    input_values.loc[0,'Item Name'] = id_product
    input_values.loc[0,'Quantity in Inventory'] = id_quantityInInventory
    input_values.loc[0,'Weather'] = id_weather
    input_values.loc[0,'Perishable Item'] = id_perishableItem
    input_values.loc[0,'Supply Quantity'] = id_supplyQuantity
   
    yhat_prob = model.predict(input_values)
    output_values = input_values
    output_values.loc[0,'Price'] = int(yhat_prob)

    return yhat_prob[0]
   
    # return the predicted values with the input values
    return output_values.to_json()

@ensure_csrf_cookie
def home(request): 

    if request.method == "POST":
        
        id_category = int(request.POST.get("category"))
        id_weather = int(request.POST.get("weather"))
        id_product = int(request.POST.get("product"))
        id_seasonality = int(request.POST.get("seasonality"))
        id_supplyQuantity = int(request.POST.get("supplyQuantity"))
        id_demandQuantity = int(request.POST.get("demandQuantity"))
        id_location = int(request.POST.get("location"))
        id_perishableItem = int(request.POST.get("perishableItem"))
        id_quantityInInventory = int(request.POST.get("quantityInInventory"))
        id_timeFrame = int(request.POST.get("timeFrame"))

        p = predict(id_category,id_weather,id_product,id_seasonality,id_supplyQuantity ,id_demandQuantity,id_location,id_perishableItem,id_quantityInInventory,id_timeFrame)
        resp = {"status":"ok","msg":"ok","error":"","price":p}
        return JsonResponse(resp)
    return render(request,'main/home.html',{"startAnalysisURL":"."})


def getPrice(request):
    if request.method == "GET":      
        id_category = int(request.GET.get("category"))
        id_weather = int(request.GET.get("weather"))
        id_product = int(request.GET.get("product"))
        id_seasonality = int(request.GET.get("seasonality"))
        id_supplyQuantity = int(request.GET.get("supplyQuantity"))
        id_demandQuantity = int(request.GET.get("demandQuantity"))
        id_location = int(request.GET.get("location"))
        id_perishableItem = int(request.GET.get("perishableItem"))
        id_quantityInInventory = int(request.GET.get("quantityInInventory"))
        id_timeFrame = int(request.GET.get("timeFrame"))

        p = predict(id_category,id_weather,id_product,id_seasonality,id_supplyQuantity ,id_demandQuantity,id_location,id_perishableItem,id_quantityInInventory,id_timeFrame)
        resp = {"status":"ok","msg":"ok","error":"","price":p}
        return JsonResponse(resp)
    else:
        return JsonResponse({"error":"do a get"})




